import { useEffect, useMemo, useState } from "react";
import { useI18n } from "@/lib/i18n";
import { waLink } from "@/lib/config";
import { GlowBlob, Section, SectionHead } from "@/components/ui";
import { IconClose, IconWhatsApp } from "@/components/Icons";
import { WORK_IMAGES } from "@/lib/work-images";
import { cn } from "@/utils/cn";

export default function Work() {
  const { t } = useI18n();
  const [filter, setFilter] = useState<string>("all");
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const cats = useMemo(
    () => Array.from(new Set(t.work.items.map((i) => i.cat))),
    [t.work.items],
  );

  const items = t.work.items
    .map((item, original) => ({ ...item, original }))
    .filter((i) => filter === "all" || i.cat === filter);

  const active = openIndex === null ? null : items[openIndex];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpenIndex(null);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    document.body.style.overflow = active ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [active]);

  return (
    <Section id="work" className="bg-ink-2/40">
      <GlowBlob className="bottom-10 start-1/4 h-80 w-80" color="bg-brand-3/12" />
      <div className="container-x relative">
        <SectionHead tag={t.work.tag} title={t.work.title} text={t.work.text} />

        <div className="reveal mt-10 flex flex-wrap justify-center gap-2.5">
          {[{ key: "all", label: t.work.all }, ...cats.map((c) => ({ key: c, label: t.work.cats[c as keyof typeof t.work.cats] }))].map(
            (f) => (
              <button
                key={f.key}
                type="button"
                onClick={() => {
                  setFilter(f.key);
                  setOpenIndex(null);
                }}
                className={cn(
                  "rounded-full px-5 py-2.5 text-sm font-bold transition",
                  filter === f.key
                    ? "grad-brand text-white shadow-[0_14px_30px_-16px_rgba(124,92,255,0.9)]"
                    : "border border-white/10 bg-white/5 text-white/60 hover:border-white/25 hover:text-white",
                )}
              >
                {f.label}
              </button>
            ),
          )}
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item, i) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setOpenIndex(i)}
              className="reveal group relative block overflow-hidden rounded-3xl border border-white/10 bg-ink-3 text-start card-hover"
              style={{ ["--reveal-delay" as string]: `${i * 60}ms` }}
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={WORK_IMAGES[item.key]}
                  alt={item.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.08]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-transparent opacity-90" />
                <span className="absolute top-4 start-4 rounded-full border border-white/15 bg-ink/70 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-brand-3 backdrop-blur">
                  {t.work.cats[item.cat as keyof typeof t.work.cats]}
                </span>
                <span className="absolute bottom-4 end-4 inline-flex h-10 w-10 translate-y-3 items-center justify-center rounded-full grad-brand text-white opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                  <IconClose className="h-4 w-4 rotate-45" />
                </span>
              </div>
              <div className="p-5">
                <h3 className="text-base font-bold">{item.title}</h3>
                <p className="mt-2 line-clamp-2 text-sm text-white/55">{item.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {active && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-ink/90 p-4 backdrop-blur-md"
          onClick={() => setOpenIndex(null)}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="relative w-full max-w-3xl overflow-hidden rounded-3xl border border-white/10 bg-ink-2 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setOpenIndex(null)}
              aria-label={t.work.close}
              className="absolute top-4 end-4 z-10 inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-ink/70 text-white backdrop-blur transition hover:bg-white/15"
            >
              <IconClose className="h-5 w-5" />
            </button>
            <img
              src={WORK_IMAGES[active.key]}
              alt={active.title}
              className="max-h-[62vh] w-full object-cover"
            />
            <div className="p-6">
              <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-brand-3">
                {t.work.cats[active.cat as keyof typeof t.work.cats]}
              </span>
              <h3 className="mt-2 text-xl font-extrabold">{active.title}</h3>
              <p className="mt-2 text-sm text-white/60">{active.desc}</p>
              <a
                href={waLink(`${t.contact.title}: ${active.title}`)}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-5 inline-flex items-center gap-2 rounded-2xl bg-[#25D366] px-5 py-3 text-sm font-bold text-[#062b16] transition hover:brightness-110"
              >
                <IconWhatsApp className="h-4 w-4" />
                {t.services.order}
              </a>
            </div>
          </div>
        </div>
      )}
    </Section>
  );
}
